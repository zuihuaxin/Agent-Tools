﻿#requires -Version 5.1
<#
  清盘侠 DiskHero  ·  专治 C 盘爆满
  ---------------------------------------------------------------
  为两类人做的：
    1. 不懂电脑、只想「点两下就好」的普通人
    2. 被各种 AI Agent 的日志、缓存、模型文件吃满硬盘的人

  设计原则
    · 只删能自己长回来的东西（缓存 / 日志 / 临时文件）
    · 不碰文档、聊天记录、账号、源码
    · 每一步都能看见「删什么、为什么删、能省多少」
    · 搬家用目录联接，程序感觉不到，日志却写到别的盘去了

  用法
    双击 启动.cmd  →  菜单操作（推荐）
    高级：QingPanXia.ps1 -Scan | -Clean -Real | -Deep -Real | -Move -Real | -Undo
#>
param(
    [switch]$Scan,
    [switch]$Clean,
    [switch]$Deep,
    [switch]$Move,
    [switch]$Undo,
    [switch]$Real,
    [switch]$Yes,
    [switch]$Preview
)

$ErrorActionPreference = 'Continue'
$ProgressPreference = 'SilentlyContinue'

# ═══════════════════════ 全局 ═══════════════════════
$Script:PKG_ROOT = Split-Path -Parent $PSScriptRoot
if (-not $Script:PKG_ROOT) { $Script:PKG_ROOT = (Get-Location).Path }
$Script:REPORT_DIR = Join-Path $Script:PKG_ROOT '报告'
$Script:STATE_FILE = Join-Path $Script:REPORT_DIR '已搬走的目录.json'
$Script:GB = 1GB

$U = $env:USERPROFILE
$L = $env:LOCALAPPDATA
$A = $env:APPDATA

# ═══════════════════════ 显示 ═══════════════════════
function Write-Title($t) {
    Write-Host ''
    Write-Host ('  ' + ('─' * 58)) -ForegroundColor DarkGray
    Write-Host ('  ' + $t) -ForegroundColor Cyan
    Write-Host ('  ' + ('─' * 58)) -ForegroundColor DarkGray
}

function GB($b) {
    if (-not $b -or $b -lt 0) { return '  0 MB' }
    if ($b -ge 1GB) { return ('{0,6:N2} GB' -f ($b / 1GB)) }
    return ('{0,6:N0} MB' -f ($b / 1MB))
}

function Say-Ok($m)   { Write-Host "  [OK]   $m" -ForegroundColor Green }
function Say-Warn($m) { Write-Host "  [注意] $m" -ForegroundColor Yellow }
function Say-Err($m)  { Write-Host "  [失败] $m" -ForegroundColor Red }
function Say-Info($m) { Write-Host "         $m" -ForegroundColor DarkGray }

function Get-Bar($pct, $width = 28) {
    $filled = [int][math]::Round($pct / 100 * $width)
    if ($filled -gt $width) { $filled = $width }
    if ($filled -lt 0) { $filled = 0 }
    return ('[' + ('#' * $filled) + ('.' * ($width - $filled)) + ']')
}

function Get-DisplayWidth([string]$s) {
    <# 中文字符占两个字符宽，用它算对齐才不错位 #>
    $w = 0
    foreach ($ch in $s.ToCharArray()) {
        $c = [int]$ch
        if (($c -ge 0x1100 -and $c -le 0x115F) -or
            ($c -ge 0x2E80 -and $c -le 0xA4CF) -or
            ($c -ge 0xAC00 -and $c -le 0xD7A3) -or
            ($c -ge 0xF900 -and $c -le 0xFAFF) -or
            ($c -ge 0xFE30 -and $c -le 0xFE6F) -or
            ($c -ge 0xFF00 -and $c -le 0xFF60) -or
            ($c -ge 0xFFE0 -and $c -le 0xFFE6)) { $w += 2 }
        else { $w += 1 }
    }
    return $w
}

function Pad-R([string]$s, [int]$w) {
    $d = $w - (Get-DisplayWidth $s)
    if ($d -lt 0) { $d = 0 }
    return $s + (' ' * $d)
}

# ═══════════════════════ 磁盘 ═══════════════════════
function Get-DiskInfo([string]$root = 'C:\') {
    $d = Get-PSDrive -Name $root.Substring(0, 1) -ErrorAction SilentlyContinue
    if (-not $d) { return $null }
    $used = $d.Used
    $free = $d.Free
    $total = $used + $free
    return [pscustomobject]@{
        Root = $root
        Total = $total
        Used = $used
        Free = $free
        Pct = $(if ($total -gt 0) { $used / $total * 100 } else { 0 })
    }
}

function Get-BestDrive {
    <# 找一个「能装东西」的盘：不是系统盘、剩余空间最大的那个 #>
    $sys = $env:SystemDrive.Substring(0, 1)
    $cands = @()
    foreach ($d in (Get-PSDrive -PSProvider FileSystem -ErrorAction SilentlyContinue)) {
        if ($d.Name -eq $sys) { continue }
        if ($null -eq $d.Free -or $null -eq $d.Used) { continue }
        if ($d.Free -lt 2GB) { continue }
        $p = $d.Root
        if (-not (Test-Path -LiteralPath $p)) { continue }
        # 排除光驱 / 可移动盘
        try {
            $di = New-Object System.IO.DriveInfo $p
            if ($di.DriveType -ne [System.IO.DriveType]::Fixed) { continue }
        } catch { continue }
        $cands += $d
    }
    if ($cands.Count -eq 0) { return $null }
    return ($cands | Sort-Object Free -Descending | Select-Object -First 1)
}

# ═══════════════════════ 体积 ═══════════════════════
function Ask-Confirm([string]$prompt, [string]$cancelPattern = '^[Nn]') {
    <#
      安全确认。返回 $true = 继续，$false = 取消。
      关键：非交互环境（管道、计划任务、自动化调用）里 Read-Host 拿不到数据，
      此时必须当成「取消」，绝不能因为读到空值就往下走 —— 那样会静默删东西。
    #>
    try { $r = Read-Host $prompt } catch { return $false }
    if ($null -eq $r) { return $false }
    if ($r -match $cancelPattern) { return $false }
    return $true
}

function Read-Choice([string]$prompt) {
    <# 读菜单选择；拿不到输入返回 $null（调用方据此退出） #>
    try { $r = Read-Host $prompt } catch { return $null }
    return $r
}

function Get-DirSize([string]$path) {
    if (-not (Test-Path -LiteralPath $path)) { return 0 }
    $item = Get-Item -LiteralPath $path -Force -ErrorAction SilentlyContinue
    if (-not $item) { return 0 }
    if (-not $item.PSIsContainer) { return $item.Length }
    $s = (Get-ChildItem -LiteralPath $path -Recurse -Force -ErrorAction SilentlyContinue |
          Measure-Object -Property Length -Sum).Sum
    if (-not $s) { return 0 }
    return $s
}

function Get-ItemCount([string]$path) {
    if (-not (Test-Path -LiteralPath $path)) { return 0 }
    return @(Get-ChildItem -LiteralPath $path -Recurse -Force -ErrorAction SilentlyContinue).Count
}

# ═══════════════════════ 删除 ═══════════════════════
function Invoke-Purge([string]$target) {
    <#
      清空一个目录的内容，但保留目录本身。
      用 robocopy 空目录镜像：比 Remove-Item 快一个数量级，
      /R:0 让被占用的文件直接跳过，不会卡住。
    #>
    if (-not (Test-Path -LiteralPath $target)) { return -1 }
    $empty = Join-Path ([System.IO.Path]::GetTempPath()) ('dh_empty_' + [guid]::NewGuid().ToString('N').Substring(0, 8))
    try {
        New-Item -ItemType Directory -Path $empty -Force | Out-Null
        robocopy.exe $empty $target /MIR /R:0 /W:0 /NFL /NDL /NJH /NJS /NP 2>&1 | Out-Null
        return $LASTEXITCODE
    } catch {
        return -2
    } finally {
        if (Test-Path -LiteralPath $empty) {
            Remove-Item -LiteralPath $empty -Force -Recurse -ErrorAction SilentlyContinue
        }
    }
}

function Resolve-Targets($def) {
    <# 把带通配符的 Pat 展开成真实路径列表 #>
    $out = @()
    try {
        foreach ($h in @(Get-Item -Path $def.Pat -Force -ErrorAction SilentlyContinue)) {
            if ($null -eq $h) { continue }
            $out += $h
        }
    } catch { }
    return $out
}

# ═══════════════════════ 清单：安全清理 ═══════════════════════
function Get-SafeTargets {
    return @(
        # ─── AI / Agent 工具（这一类最容易被忽视，也最肥） ───
        @{ Cat = 'AI 工具'; Name = 'WorkBuddy 沙箱日志';      Pat = "$U\.workbuddy\logs\sandbox";            Kind = 'Purge' }
        @{ Cat = 'AI 工具'; Name = 'WorkBuddy 会话轨迹';      Pat = "$U\.workbuddy\traces";                  Kind = 'OldItems'; Days = 1 }
        @{ Cat = 'AI 工具'; Name = 'Claude 终端快照';         Pat = "$U\.claude\shell-snapshots";            Kind = 'Purge' }
        @{ Cat = 'AI 工具'; Name = 'Claude 会话记录缓存';     Pat = "$U\.claude\todos";                      Kind = 'Purge' }
        @{ Cat = 'AI 工具'; Name = 'Codex 缓存';              Pat = "$U\.codex\cache";                       Kind = 'Purge' }
        @{ Cat = 'AI 工具'; Name = 'Cursor 缓存';             Pat = "$U\.cursor\Cache";                      Kind = 'Purge' }
        @{ Cat = 'AI 工具'; Name = 'Cursor 工作区缓存';       Pat = "$U\.cursor\CachedData";                 Kind = 'Purge' }
        @{ Cat = 'AI 工具'; Name = 'Gemini CLI 缓存';         Pat = "$U\.gemini\tmp";                        Kind = 'Purge' }
        @{ Cat = 'AI 工具'; Name = 'Aider 缓存';              Pat = "$U\.aider\cache";                       Kind = 'Purge' }
        @{ Cat = 'AI 工具'; Name = 'Continue 索引';           Pat = "$U\.continue\index";                    Kind = 'Purge' }

        # ─── 包管理器 / 下载缓存（删了下次装依赖会重下，不影响已装好的） ───
        @{ Cat = '开发缓存'; Name = 'pip 下载缓存';           Pat = "$L\pip\cache";                          Kind = 'Purge' }
        @{ Cat = '开发缓存'; Name = 'uv 包缓存';              Pat = "$U\.cache\uv";                          Kind = 'Purge' }
        @{ Cat = '开发缓存'; Name = 'npm 缓存';               Pat = "$L\npm-cache";                          Kind = 'Purge' }
        @{ Cat = '开发缓存'; Name = 'npm 缓存(旧位置)';       Pat = "$A\npm-cache";                          Kind = 'Purge' }
        @{ Cat = '开发缓存'; Name = 'Yarn 缓存';              Pat = "$L\Yarn\Cache";                         Kind = 'Purge' }
        @{ Cat = '开发缓存'; Name = 'pnpm 缓存';              Pat = "$L\pnpm\store";                         Kind = 'Purge' }
        @{ Cat = '开发缓存'; Name = 'Playwright 浏览器包';    Pat = "$L\ms-playwright";                      Kind = 'Purge' }
        @{ Cat = '开发缓存'; Name = 'HuggingFace 下载缓存';   Pat = "$U\.cache\huggingface\hub";             Kind = 'Purge' }
        @{ Cat = '开发缓存'; Name = 'yt-dlp 缓存';            Pat = "$U\.cache\yt-dlp";                      Kind = 'Purge' }
        @{ Cat = '开发缓存'; Name = 'Whisper 模型缓存';       Pat = "$U\.cache\whisper";                     Kind = 'Purge' }
        @{ Cat = '开发缓存'; Name = 'Gradle 缓存';            Pat = "$U\.gradle\caches";                     Kind = 'OldItems'; Days = 30 }
        @{ Cat = '开发缓存'; Name = 'Maven 本地库(旧包)';     Pat = "$U\.m2\repository";                     Kind = 'OldItems'; Days = 90 }

        # ─── 浏览器网页缓存 ───
        @{ Cat = '浏览器'; Name = 'Chrome 网页缓存';          Pat = "$L\Google\Chrome\User Data\*\Service Worker"; Kind = 'Purge' }
        @{ Cat = '浏览器'; Name = 'Chrome Cache';             Pat = "$L\Google\Chrome\User Data\*\Cache";          Kind = 'Purge' }
        @{ Cat = '浏览器'; Name = 'Chrome Code Cache';        Pat = "$L\Google\Chrome\User Data\*\Code Cache";     Kind = 'Purge' }
        @{ Cat = '浏览器'; Name = 'Chrome GPU 缓存';          Pat = "$L\Google\Chrome\User Data\*\GPUCache";       Kind = 'Purge' }
        @{ Cat = '浏览器'; Name = 'Edge 网页缓存';            Pat = "$L\Microsoft\Edge\User Data\*\Service Worker"; Kind = 'Purge' }
        @{ Cat = '浏览器'; Name = 'Edge Cache';               Pat = "$L\Microsoft\Edge\User Data\*\Cache";          Kind = 'Purge' }
        @{ Cat = '浏览器'; Name = 'Edge Code Cache';          Pat = "$L\Microsoft\Edge\User Data\*\Code Cache";     Kind = 'Purge' }
        @{ Cat = '浏览器'; Name = 'Firefox 缓存';             Pat = "$L\Mozilla\Firefox\Profiles\*\cache2";         Kind = 'Purge' }
        @{ Cat = '浏览器'; Name = '360 浏览器缓存';           Pat = "$L\360Chrome\Chrome\User Data\*\Cache";        Kind = 'Purge' }
        @{ Cat = '浏览器'; Name = 'QQ 浏览器缓存';            Pat = "$L\Tencent\QQBrowser\User Data\*\Cache";       Kind = 'Purge' }

        # ─── 办公 / 聊天软件缓存 ───
        @{ Cat = '常用软件'; Name = '飞书内置浏览器缓存';     Pat = "$A\LarkShell\aha\users\*\profile_explorer\Service Worker"; Kind = 'Purge' }
        @{ Cat = '常用软件'; Name = '飞书内置浏览器 Cache';   Pat = "$A\LarkShell\aha\users\*\profile_explorer\Cache";          Kind = 'Purge' }
        @{ Cat = '常用软件'; Name = '飞书小程序沙箱';         Pat = "$A\LarkShell\sandbox_runtime";          Kind = 'Purge' }
        @{ Cat = '常用软件'; Name = '飞书代码缓存';           Pat = "$A\LarkShell\CodeCache";                Kind = 'Purge' }
        @{ Cat = '常用软件'; Name = '微信运行日志(旧)';       Pat = "$A\Tencent\xwechat\log";                Kind = 'OldItems'; Days = 3 }
        @{ Cat = '常用软件'; Name = '微信旧运行日志';         Pat = "$A\Tencent\WeChat\log";                 Kind = 'OldItems'; Days = 3 }
        @{ Cat = '常用软件'; Name = '钉钉日志缓存';           Pat = "$A\DingTalk\log";                       Kind = 'OldItems'; Days = 3 }
        @{ Cat = '常用软件'; Name = '豆包网页缓存';           Pat = "$L\Doubao*\User Data\gecko_cache";      Kind = 'Purge' }
        @{ Cat = '常用软件'; Name = '豆包沙箱运行时';         Pat = "$L\Doubao*\User Data\sandbox_runtime";  Kind = 'Purge' }
        @{ Cat = '常用软件'; Name = 'WPS 下载的安装包';       Pat = "$A\kingsoft\wps\download";              Kind = 'Purge' }

        # ─── 系统临时 ───
        @{ Cat = '系统临时'; Name = '用户临时目录 Temp';      Pat = "$L\Temp";                               Kind = 'Purge' }
        @{ Cat = '系统临时'; Name = 'Windows 临时目录';       Pat = "$env:WINDIR\Temp";                      Kind = 'Purge' }
        @{ Cat = '系统临时'; Name = '打包工具残留 (_MEI)';    Pat = "$L\Temp\_MEI*";                         Kind = 'Purge' }
    )
}

# ═══════════════════════ 清单：深度清理 ═══════════════════════
function Get-DeepTargets {
    return @(
        @{ Cat = '旧版本残留'; Name = 'WPS 插件池(旧版本堆积)';   Pat = "$A\kingsoft\wps\addons\pool";  Kind = 'Purge' }
        @{ Cat = '旧版本残留'; Name = 'WPS 清理工具缓存';         Pat = "$L\Kingsoft\kaccclear";        Kind = 'Purge' }
        @{ Cat = '旧版本残留'; Name = '金山毒霸组件';             Pat = "$A\kingsoft\duba";             Kind = 'Purge' }
        @{ Cat = '旧版本残留'; Name = 'NVIDIA 安装包缓存';        Pat = 'C:\ProgramData\NVIDIA Corporation\NVIDIA App\UpdateFramework\ota-artifacts'; Kind = 'Purge' }
        @{ Cat = '旧版本残留'; Name = 'WPS 旧版本程序';           Pat = "$L\Kingsoft\WPS Office";       Kind = 'KeepNewest' }
        @{ Cat = '旧版本残留'; Name = '各类更新包 installer.exe'; Pat = "$L\*updater\installer.exe";    Kind = 'Files' }
        @{ Cat = '旧版本残留'; Name = '模型下载残片 .corrupt';    Pat = "$U\.cache\huggingface\**\*.corrupt"; Kind = 'Files' }
        @{ Cat = '旧版本残留'; Name = 'AI 工具旧项目副本';        Pat = "$U\.workbuddy\projects";       Kind = 'OldItems'; Days = 30 }
    )
}

# ═══════════════════════ 清单：可搬家的目录 ═══════════════════════
function Get-MovableTargets {
    return @(
        @{ Name = 'WorkBuddy 日志';   Src = "$U\.workbuddy\logs";       Desc = '每天的运行日志，增长最快' }
        @{ Name = 'WorkBuddy 轨迹';   Src = "$U\.workbuddy\traces";     Desc = '会话轨迹，动辄几个 G' }
        @{ Name = 'WorkBuddy 工作区'; Src = "$U\.workbuddy\workspace";  Desc = '临时工作区，小文件极多' }
        @{ Name = 'Claude 会话';      Src = "$U\.claude\projects";      Desc = '历史会话记录' }
        @{ Name = 'HuggingFace 模型'; Src = "$U\.cache\huggingface";    Desc = '下载的 AI 模型，往往几十 G' }
        @{ Name = 'Ollama 模型';      Src = "$U\.ollama\models";        Desc = '本地大模型，单个就几个 G' }
        @{ Name = 'npm 缓存';         Src = "$L\npm-cache";             Desc = '依赖包缓存' }
        @{ Name = 'pip 缓存';         Src = "$L\pip\cache";             Desc = 'Python 包缓存' }
        @{ Name = 'Playwright 浏览器'; Src = "$L\ms-playwright";        Desc = '自动化用的浏览器内核' }
    )
}

# ═══════════════════════ 扫描 ═══════════════════════
function Invoke-Scan {
    param([switch]$Quiet)

    $disk = Get-DiskInfo 'C:\'
    if (-not $Quiet) {
        Write-Title '体检 · 看看谁在吃你的 C 盘'
        Say-Info "C 盘：已用 $(GB $disk.Used) / 共 $(GB $disk.Total)　剩余 $(GB $disk.Free)"
        Say-Info ("       " + (Get-Bar $disk.Pct) + ('  {0:N0}% 已用' -f $disk.Pct))
        Write-Host ''
        Say-Info '正在扫描，文件多的话要等一会儿...'
    }

    $rows = @()

    # A. AI 工具单独统计
    $aiRoots = @(
        @{ N = 'WorkBuddy'; P = "$U\.workbuddy" }
        @{ N = 'Claude Code'; P = "$U\.claude" }
        @{ N = 'Codex'; P = "$U\.codex" }
        @{ N = 'Cursor'; P = "$U\.cursor" }
        @{ N = 'Ollama 模型'; P = "$U\.ollama" }
        @{ N = 'HuggingFace'; P = "$U\.cache\huggingface" }
    )
    foreach ($r in $aiRoots) {
        if (Test-Path -LiteralPath $r.P) {
            $rows += [pscustomobject]@{ Cat = 'AI 工具'; Name = $r.N; Path = $r.P; Size = (Get-DirSize $r.P) }
        }
    }

    # B. 常见软件目录
    $softRoots = @(
        @{ N = 'Chrome'; P = "$L\Google\Chrome" }
        @{ N = 'Edge'; P = "$L\Microsoft\Edge" }
        @{ N = '飞书'; P = "$A\LarkShell" }
        @{ N = '微信'; P = "$A\Tencent\xwechat" }
        @{ N = 'WPS'; P = "$A\kingsoft" }
        @{ N = 'WPS 程序'; P = "$L\Kingsoft" }
        @{ N = '豆包'; P = "$L\Doubao" }
        @{ N = '豆包办公'; P = "$L\DoubaoWork" }
        @{ N = '钉钉'; P = "$A\DingTalk" }
        @{ N = '临时文件'; P = "$L\Temp" }
        @{ N = 'pip 缓存'; P = "$L\pip" }
        @{ N = 'npm 缓存'; P = "$L\npm-cache" }
    )
    foreach ($r in $softRoots) {
        if (Test-Path -LiteralPath $r.P) {
            $rows += [pscustomobject]@{ Cat = '常用软件'; Name = $r.N; Path = $r.P; Size = (Get-DirSize $r.P) }
        }
    }

    $rows = @($rows | Sort-Object Size -Descending)

    if ($Quiet) { return [pscustomobject]@{ Disk = $disk; Rows = $rows } }

    Write-Host ''
    Write-Host '  排行榜（只列超过 200 MB 的）' -ForegroundColor White
    Write-Host ('  ' + ('-' * 62)) -ForegroundColor DarkGray
    $i = 0
    foreach ($r in $rows) {
        if ($r.Size -lt 200MB) { continue }
        $i++
        $tag = $(if ($r.Cat -eq 'AI 工具') { '[AI]' } else { '[  ]' })
        $line = '  {0,2}. {1} {2} {3}' -f $i, $tag, (Pad-R $r.Name 22), (GB $r.Size)
        if ($r.Cat -eq 'AI 工具') { Write-Host $line -ForegroundColor Yellow }
        else { Write-Host $line }
    }
    Write-Host ('  ' + ('-' * 62)) -ForegroundColor DarkGray

    # 可清量估算（只做快的部分，真正的准确数字在选 [2]/[3] 时算）
    $aiTotal = ($rows | Where-Object { $_.Cat -eq 'AI 工具' } | Measure-Object Size -Sum).Sum
    if (-not $aiTotal) { $aiTotal = 0 }

    Write-Host ''
    Write-Host ('  AI 工具合计占用：' + (GB $aiTotal)) -ForegroundColor Yellow
    Write-Host '  下一步：想看能清多少，选 [2] 快清 或 [3] 深清，会先列清单问你。' -ForegroundColor Green

    # 写报告
    try {
        New-Item -ItemType Directory -Path $Script:REPORT_DIR -Force | Out-Null
        $csv = Join-Path $Script:REPORT_DIR ('体检_{0:yyyyMMdd_HHmm}.csv' -f (Get-Date))
        $rows | Select-Object @{n='类别';e={$_.Cat}}, @{n='名称';e={$_.Name}}, @{n='大小GB';e={[math]::Round($_.Size/1GB, 2)}}, @{n='路径';e={$_.Path}} |
            Export-Csv -Path $csv -NoTypeInformation -Encoding UTF8
        Write-Host ''
        Say-Ok "明细已存到 报告\$(Split-Path $csv -Leaf)"
    } catch { }

    return [pscustomobject]@{ Disk = $disk; Rows = $rows; Ai = $aiTotal }
}

# ═══════════════════════ 计划 ═══════════════════════
function Build-Plan($defs) {
    <# 把清单变成「要删的路径 + 体积」，同时算出总数 #>
    $plan = @()
    foreach ($d in $defs) {
        $hits = @(Resolve-Targets $d)
        foreach ($h in $hits) {
            if ($null -eq $h) { continue }
            if ($null -eq $h.PSIsContainer -and $h.PSIsContainer -ne $false) { continue }
            $isDir = $true
            try { $isDir = [bool]$h.PSIsContainer } catch { $isDir = $true }

            $sz = 0
            switch ($d.Kind) {
                'OldItems' {
                    if (-not $isDir) { continue }
                    $cut = (Get-Date).AddDays(-1 * $d.Days)
                    $old = @(Get-ChildItem -LiteralPath $h.FullName -Force -ErrorAction SilentlyContinue |
                             Where-Object { $_.LastWriteTime -lt $cut })
                    $sz = ($old | ForEach-Object {
                        if ($_.PSIsContainer) { Get-DirSize $_.FullName } else { $_.Length }
                    } | Measure-Object -Sum).Sum
                    if (-not $sz) { $sz = 0 }
                    if ($sz -eq 0) { continue }
                }
                'Files' {
                    $f = Get-Item -LiteralPath $h.FullName -Force -ErrorAction SilentlyContinue
                    if ($f -and -not $f.PSIsContainer) { $sz = $f.Length } else { continue }
                }
                'KeepNewest' {
                    <# 一个目录下堆着好几个版本号文件夹时，只留最新的那一个。
                       只认「数字开头」的子目录（12.1.0.29161 这种），别的一律不碰。 #>
                    if (-not $isDir) { continue }
                    $subs = @(Get-ChildItem -LiteralPath $h.FullName -Directory -Force -ErrorAction SilentlyContinue |
                              Where-Object { $_.Name -match '^\d+(\.\d+)+$' } |
                              Sort-Object Name -Descending)
                    if ($subs.Count -le 1) { continue }
                    $sz = ($subs | Select-Object -Skip 1 | ForEach-Object { Get-DirSize $_.FullName } | Measure-Object -Sum).Sum
                    if (-not $sz) { $sz = 0 }
                    if ($sz -eq 0) { continue }
                }
                default {
                    $sz = Get-DirSize $h.FullName
                    if ($sz -eq 0) { continue }
                }
            }

            $plan += [pscustomobject]@{
                Cat  = $d.Cat
                Name = $d.Name
                Kind = $d.Kind
                Days = $d.Days
                Path = $h.FullName
                Size = $sz
            }
        }
    }
    # 小于 1 MB 的不值得列，过滤掉少点噪音
    return @($plan | Where-Object { $_.Size -ge 1MB } | Sort-Object @{Expression='Cat';Ascending=$true}, @{Expression='Size';Descending=$true})
}

function Get-PlanTotal($defs) {
    $p = Build-Plan $defs
    $s = ($p | Measure-Object Size -Sum).Sum
    if (-not $s) { return 0 }
    return $s
}

function Show-Plan($plan, $title) {
    Write-Title $title
    if ($plan.Count -eq 0) {
        Say-Ok '没有找到可清理的内容，你的电脑已经很干净了。'
        return
    }
    $lastCat = ''
    foreach ($p in ($plan | Sort-Object Cat, @{Expression='Size';Descending=$true})) {
        if ($p.Cat -ne $lastCat) {
            Write-Host ''
            Write-Host ("  【" + $p.Cat + "】") -ForegroundColor DarkCyan
            $lastCat = $p.Cat
        }
        Write-Host ("   " + (GB $p.Size) + "  " + $p.Name)
        Say-Info $p.Path
    }
    $total = ($plan | Measure-Object Size -Sum).Sum
    Write-Host ''
    Write-Host ('  ' + ('-' * 58)) -ForegroundColor DarkGray
    Write-Host ('  合计可释放：' + (GB $total) + '（' + $plan.Count + ' 处）') -ForegroundColor Green
    return $total
}

# ═══════════════════════ 执行清理 ═══════════════════════
function Invoke-CleanPlan($plan, $title) {
    Write-Title $title
    $before = (Get-DiskInfo 'C:\').Free
    $okCount = 0
    $failCount = 0
    $logRows = @()

    foreach ($p in ($plan | Sort-Object Size -Descending)) {
        switch ($p.Kind) {
            'OldItems' {
                $cut = (Get-Date).AddDays(-1 * $p.Days)
                $old = @(Get-ChildItem -LiteralPath $p.Path -Force -ErrorAction SilentlyContinue |
                         Where-Object { $_.LastWriteTime -lt $cut })
                foreach ($o in $old) {
                    try { Remove-Item -LiteralPath $o.FullName -Recurse -Force -ErrorAction Stop; $okCount++ }
                    catch { $failCount++ }
                }
                Write-Host ("   " + (GB $p.Size) + "  " + $p.Name) -ForegroundColor Green
            }
            'Files' {
                try { Remove-Item -LiteralPath $p.Path -Force -ErrorAction Stop; $okCount++ }
                catch { $failCount++ }
                Write-Host ("   " + (GB $p.Size) + "  " + $p.Name) -ForegroundColor Green
            }
            'KeepNewest' {
                $subs = @(Get-ChildItem -LiteralPath $p.Path -Directory -Force -ErrorAction SilentlyContinue |
                          Where-Object { $_.Name -match '^\d+(\.\d+)+$' } |
                          Sort-Object Name -Descending | Select-Object -Skip 1)
                foreach ($s in $subs) {
                    try { Remove-Item -LiteralPath $s.FullName -Recurse -Force -ErrorAction Stop; $okCount++ }
                    catch { $failCount++ }
                }
                Write-Host ("   " + (GB $p.Size) + "  " + $p.Name) -ForegroundColor Green
            }
            default {
                $rc = Invoke-Purge $p.Path
                if ($rc -ge 8 -or $rc -eq -2) { $failCount++ } else { $okCount++ }
                $left = Get-ItemCount $p.Path
                if ($left -gt 0) {
                    Write-Host ("   " + (GB $p.Size) + "  " + $p.Name + "  (还剩 $left 项被占用)") -ForegroundColor Yellow
                } else {
                    Write-Host ("   " + (GB $p.Size) + "  " + $p.Name) -ForegroundColor Green
                }
            }
        }
        $logRows += [pscustomobject]@{ 时间=(Get-Date -Format 'HH:mm:ss'); 项目=$p.Name; 释放GB=[math]::Round($p.Size/1GB,2); 路径=$p.Path }
    }

    $after = (Get-DiskInfo 'C:\').Free
    $delta = ($after - $before) / 1GB
    Write-Host ''
    Write-Host ('  ' + ('-' * 58)) -ForegroundColor DarkGray
    Write-Host ('  实际释放：{0:N2} GB' -f $delta) -ForegroundColor Green
    Write-Host ('  C 盘剩余：' + (GB $after) + ' / 共 ' + (GB (Get-DiskInfo 'C:\').Total))
    if ($failCount -gt 0) {
        Say-Warn "有 $failCount 处被程序占用没清干净。关掉对应的软件（或重启电脑）后再跑一次就好。"
    }

    try {
        New-Item -ItemType Directory -Path $Script:REPORT_DIR -Force | Out-Null
        $lf = Join-Path $Script:REPORT_DIR ('清理记录_{0:yyyyMMdd_HHmmss}.csv' -f (Get-Date))
        $logRows | Export-Csv -Path $lf -NoTypeInformation -Encoding UTF8
        Say-Info "记录已存到 报告\$(Split-Path $lf -Leaf)"
    } catch { }
}

# ═══════════════════════ 搬家 ═══════════════════════
function Get-MovePlan {
    $plan = @()
    foreach ($m in (Get-MovableTargets)) {
        if (-not (Test-Path -LiteralPath $m.Src)) { continue }
        $it = Get-Item -LiteralPath $m.Src -Force -ErrorAction SilentlyContinue
        if (-not $it) { continue }
        $isLink = [bool]($it.Attributes -band [IO.FileAttributes]::ReparsePoint)
        $tgt = ''
        if ($isLink) {
            try {
                $t = $it.Target
                if ($t -is [array]) { $t = $t[0] }
                $tgt = [string]$t
            } catch { }
        }
        $sz = 0
        if ($isLink) {
            # 已经是联接的，别再算一遍体积（那算的是目标盘的内容），只取目标盘占用
            $sz = 0
            if ($tgt) { $sz = Get-DirSize $tgt }
        } else {
            $sz = Get-DirSize $m.Src
        }
        if (-not $isLink -and $sz -lt 100MB) { continue }
        $plan += [pscustomobject]@{
            Name = $m.Name; Src = $m.Src; Desc = $m.Desc
            Size = $sz; IsLink = $isLink; Target = $tgt
        }
    }
    return $plan
}

function Get-ExistingMoveRoot {
    <# 如果之前已经搬过（比如用老版本工具搬到了别的目录），沿用它原来的存放根，
       避免同一台机器上东西散落在两个地方。 #>
    $roots = @()
    foreach ($m in (Get-MovableTargets)) {
        $it = Get-Item -LiteralPath $m.Src -Force -ErrorAction SilentlyContinue
        if (-not $it) { continue }
        if (-not ($it.Attributes -band [IO.FileAttributes]::ReparsePoint)) { continue }
        try {
            $t = $it.Target
            if ($t -is [array]) { $t = $t[0] }
            if ($t) { $roots += (Split-Path ([string]$t) -Parent) }
        } catch { }
    }
    if ($roots.Count -eq 0) { return $null }
    return ($roots | Group-Object | Sort-Object Count -Descending | Select-Object -First 1).Name
}

function Read-MoveState {
    if (-not (Test-Path -LiteralPath $Script:STATE_FILE)) { return @() }
    try {
        $s = @(Get-Content -LiteralPath $Script:STATE_FILE -Raw -Encoding UTF8 | ConvertFrom-Json)
        return $s
    } catch { return @() }
}

function Sync-LinkState {
    <# 把系统里「已经是联接」的目录补录进搬家记录，
       这样即使用老版本工具搬过、或者记录丢了，还原功能仍然认得它们。 #>
    $state = @(Read-MoveState)
    $changed = $false
    foreach ($m in (Get-MovePlan)) {
        if (-not $m.IsLink) { continue }
        if (-not $m.Target) { continue }
        if ($state | Where-Object { $_.Src -eq $m.Src }) { continue }
        $state += [pscustomobject]@{
            Name = $m.Name; Src = $m.Src; Dst = $m.Target
            Time = (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'); Note = '自动补录'
        }
        $changed = $true
    }
    if ($changed) {
        try {
            New-Item -ItemType Directory -Path $Script:REPORT_DIR -Force | Out-Null
            $state | ConvertTo-Json -Depth 4 | Out-File -FilePath $Script:STATE_FILE -Encoding UTF8
        } catch { }
    }
    return $state
}

function Invoke-MovePlan($plan, $dstRoot) {
    Write-Title '搬家 · 把大目录挪到空间大的盘'
    Say-Info "目标位置：$dstRoot"
    Say-Info '搬完会在原位置留一个「目录联接」，程序照样找得到，但文件实际在另一个盘。'
    Write-Host ''

    $state = @(Sync-LinkState)

    $before = (Get-DiskInfo 'C:\').Free
    foreach ($m in $plan) {
        if ($m.IsLink) {
            Say-Info ("已经是联接，跳过：{0}  ->  {1}" -f $m.Name, $m.Target)
            continue
        }
        $dst = Join-Path $dstRoot $m.Name
        Write-Host ("   正在搬 " + $m.Name + "  " + (GB $m.Size))
        New-Item -ItemType Directory -Path $dst -Force | Out-Null
        robocopy.exe $m.Src $dst /MOVE /E /NFL /NDL /NJH /NJS /R:0 /W:0 2>&1 | Out-Null

        if (Test-Path -LiteralPath $m.Src) {
            $left = Get-ItemCount $m.Src
            if ($left -gt 0) {
                Say-Warn "$($m.Name)：还剩 $left 项被占用没搬走，本次不建联接（避免半截）。关掉相关软件后再试。"
                continue
            }
            Remove-Item -LiteralPath $m.Src -Force -Recurse -ErrorAction SilentlyContinue
        }
        try {
            New-Item -ItemType Junction -Path $m.Src -Target $dst -ErrorAction Stop | Out-Null
            Say-Ok "$($m.Name) 已搬走并接好"
            $state += [pscustomobject]@{ Name=$m.Name; Src=$m.Src; Dst=$dst; Time=(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') }
        } catch {
            Say-Err "$($m.Name) 建联接失败：$($_.Exception.Message)"
        }
    }

    try {
        New-Item -ItemType Directory -Path $Script:REPORT_DIR -Force | Out-Null
        $state | ConvertTo-Json -Depth 4 | Out-File -FilePath $Script:STATE_FILE -Encoding UTF8
    } catch { }

    $after = (Get-DiskInfo 'C:\').Free
    Write-Host ''
    Write-Host ('  本次腾出：{0:N2} GB　C 盘剩余 {1}' -f (($after - $before) / 1GB), (GB $after)) -ForegroundColor Green
    Write-Host '  以后这些目录新产生的文件都会写到大盘，C 盘不会再被慢慢吃满。' -ForegroundColor Green
}

function Invoke-UndoMove {
    Write-Title '还原 · 把搬走的东西搬回 C 盘'
    $state = @(Sync-LinkState)
    if ($state.Count -eq 0) {
        Say-Warn '没有搬家记录，也没什么可还原的。'
        return
    }

    foreach ($s in $state) {
        Write-Host ("   " + $s.Name)
        if (-not (Test-Path -LiteralPath $s.Dst)) { Say-Warn "  源数据不在了：$($s.Dst)"; continue }
        $it = Get-Item -LiteralPath $s.Src -Force -ErrorAction SilentlyContinue
        if ($it -and ($it.Attributes -band [IO.FileAttributes]::ReparsePoint)) {
            Remove-Item -LiteralPath $s.Src -Force -Recurse -ErrorAction SilentlyContinue
        }
        robocopy.exe $s.Dst $s.Src /MOVE /E /NFL /NDL /NJH /NJS /R:0 /W:0 2>&1 | Out-Null
        if (Test-Path -LiteralPath $s.Src) { Say-Ok "已搬回 $($s.Src)" } else { Say-Err "搬回失败 $($s.Src)" }
    }
    Remove-Item -LiteralPath $Script:STATE_FILE -Force -ErrorAction SilentlyContinue
    Say-Ok '还原完成。'
}

# ═══════════════════════ 主菜单 ═══════════════════════
function Show-Header {
    Clear-Host
    $d = Get-DiskInfo 'C:\'
    $state = '健康'
    $color = 'Green'
    if ($d.Pct -ge 90 -or $d.Free -lt 5GB) { $state = '告急'; $color = 'Red' }
    elseif ($d.Pct -ge 80 -or $d.Free -lt 15GB) { $state = '紧张'; $color = 'Yellow' }

    $freeText = ('{0:N2} GB' -f ($d.Free / 1GB))
    $totalText = ('{0:N0} GB' -f ($d.Total / 1GB))

    Write-Host ''
    Write-Host '   ============================================================' -ForegroundColor Cyan
    Write-Host '      清 盘 侠   DiskHero' -ForegroundColor Cyan
    Write-Host '      专治 C 盘爆满 · 让电脑喘口气' -ForegroundColor DarkGray
    Write-Host '   ============================================================' -ForegroundColor Cyan
    Write-Host ''
    Write-Host ("      C 盘  " + (Get-Bar $d.Pct) + ("  {0:N0}% 已用" -f $d.Pct)) -ForegroundColor $color
    Write-Host ("            剩余 " + $freeText + "  /  共 " + $totalText + "      状态：" + $state) -ForegroundColor $color
    Write-Host ''
}

function Show-Menu {
    Write-Host '   ------------------------------------------------------------' -ForegroundColor DarkGray
    $rows = @(
        @('1', '体检', '看看谁在吃你的 C 盘',     '（只看不改）'),
        @('2', '快清', '缓存 / 日志 / 临时文件',   '（零风险，推荐）'),
        @('3', '深清', '旧版本 / 安装包残留',      '（会先问你）'),
        @('4', '搬家', '把日志搬到别的盘，治本',   '（推荐老用户）'),
        @('5', '还原', '把搬家搬回去',             '（后悔药）')
    )
    foreach ($r in $rows) {
        $line = '    [{0}]  {1}  {2}  {3}' -f $r[0], (Pad-R $r[1] 4), (Pad-R $r[2] 30), $r[3]
        Write-Host $line -ForegroundColor White
    }
    Write-Host '    [0]  退出' -ForegroundColor DarkGray
    Write-Host '   ------------------------------------------------------------' -ForegroundColor DarkGray
    Write-Host ''
}

function Start-Menu {
    while ($true) {
        Show-Header
        Show-Menu
        $ch = Read-Choice '   请输入数字后回车'
        if ($null -eq $ch) {
            # 非交互环境（或输入流断了）：直接退出，不能死循环
            Write-Host ''
            Say-Warn '读不到输入，已退出。'
            return
        }
        switch ($ch) {
            '1' {
                $r = Invoke-Scan
                Write-Host ''
                if ($null -eq (Read-Choice '   按回车返回菜单')) { return }
            }
            '2' {
                $plan = Build-Plan (Get-SafeTargets)
                $t = Show-Plan $plan '快清 · 缓存 / 日志 / 临时文件'
                if ($plan.Count -gt 0) {
                    Write-Host ''
                    if (Ask-Confirm '   确认清理？直接回车执行，输入 n 取消') {
                        Invoke-CleanPlan $plan '正在清理'
                    } else { Say-Info '已取消。' }
                }
                Write-Host ''
                if ($null -eq (Read-Choice '   按回车返回菜单')) { return }
            }
            '3' {
                $plan = Build-Plan (Get-DeepTargets)
                $t = Show-Plan $plan '深清 · 旧版本 / 安装包残留'
                if ($plan.Count -gt 0) {
                    Write-Host ''
                    Say-Warn '深度清理会删掉旧版本程序、插件池、更新包，相关软件首次启动时会重新下载。'
                    if (Ask-Confirm '   确认清理？直接回车执行，输入 n 取消') {
                        Invoke-CleanPlan $plan '正在深度清理'
                    } else { Say-Info '已取消。' }
                }
                Write-Host ''
                if ($null -eq (Read-Choice '   按回车返回菜单')) { return }
            }
            '4' {
                $existing = Get-ExistingMoveRoot
                $best = Get-BestDrive
                $root = $existing
                if (-not $root) {
                    if (-not $best) {
                        Write-Title '搬家'
                        Say-Err '没找到第二个可用的大容量硬盘（或者其它盘也快满了）。'
                        Say-Info '搬家需要一块剩余 2 GB 以上的固定硬盘（D / E / F 盘都行）。'
                        Write-Host ''
                        if ($null -eq (Read-Choice '   按回车返回菜单')) { return }
                        continue
                    }
                    $root = $best.Root.TrimEnd('\') + '\DiskHero'
                }
                $plan = Get-MovePlan
                Write-Title '搬家 · 把大目录挪到空间大的盘'
                if ($plan.Count -eq 0) {
                    Say-Ok '没有需要搬的大目录（超过 100 MB 的才算）。'
                    Write-Host ''
                    if ($null -eq (Read-Choice '   按回车返回菜单')) { return }
                    continue
                }
                Say-Info "存放位置：$root"
                Write-Host ''
                $sum = 0
                $todo = 0
                foreach ($m in $plan) {
                    if ($m.IsLink) {
                        Write-Host ("      已搬    " + $m.Name + "    ->  " + $m.Target) -ForegroundColor DarkGray
                        continue
                    }
                    Write-Host ("   " + (GB $m.Size) + "  " + $m.Name)
                    Say-Info ($m.Src + "   —— " + $m.Desc)
                    $sum += $m.Size
                    $todo++
                }
                Write-Host ''
                if ($todo -eq 0) {
                    Say-Ok '能搬的都已经搬完了，没有新东西要搬。'
                    Write-Host ''
                    if ($null -eq (Read-Choice '   按回车返回菜单')) { return }
                    continue
                }
                Write-Host ('   本次还能腾出：' + (GB $sum) + '（' + $todo + ' 项）') -ForegroundColor Green
                Write-Host ''
                Say-Warn '搬家时请先关掉相关的软件（尤其是正在跑的 AI 工具），否则文件被占用搬不动。'
                if (Ask-Confirm '   确认搬家？直接回车执行，输入 n 取消') {
                    Invoke-MovePlan $plan $root
                } else { Say-Info '已取消。' }
                Write-Host ''
                if ($null -eq (Read-Choice '   按回车返回菜单')) { return }
            }
            '5' {
                Invoke-UndoMove
                Write-Host ''
                if ($null -eq (Read-Choice '   按回车返回菜单')) { return }
            }
            '0' { return }
            default { }
        }
    }
}

# ═══════════════════════ 入口 ═══════════════════════
if ($Preview) {
    # 只打印一帧菜单（用于截图和文档演示，不做任何扫描或修改）
    Show-Header
    Show-Menu
    exit 0
}

if ($Scan -or $Clean -or $Deep -or $Move -or $Undo) {
    # 命令行模式（给自动化和高级用户用）
    if ($Scan) { Invoke-Scan | Out-Null; exit 0 }
    if ($Clean) {
        $plan = Build-Plan (Get-SafeTargets)
        $t = Show-Plan $plan '快清 · 预演'
        if ($Real -and $plan.Count -gt 0) {
            if ($Yes -or (Ask-Confirm '确认清理？输入 Y 继续', '^(?![Yy])')) {
                Invoke-CleanPlan $plan '正在清理'
            }
        }
        exit 0
    }
    if ($Deep) {
        $plan = Build-Plan (Get-DeepTargets)
        $t = Show-Plan $plan '深清 · 预演'
        if ($Real -and $plan.Count -gt 0) {
            if ($Yes -or (Ask-Confirm '确认清理？输入 Y 继续', '^(?![Yy])')) {
                Invoke-CleanPlan $plan '正在深度清理'
            }
        }
        exit 0
    }
    if ($Move) {
        $existing = Get-ExistingMoveRoot
        $best = Get-BestDrive
        $root = $existing
        if (-not $root) {
            if (-not $best) { Say-Err '没有可用的第二块硬盘'; exit 1 }
            $root = $best.Root.TrimEnd('\') + '\DiskHero'
        }
        $plan = Get-MovePlan
        Write-Title '搬家 · 预演'
        Say-Info "存放位置：$root"
        Write-Host ''
        $sum = 0
        $todo = 0
        foreach ($m in $plan) {
            if ($m.IsLink) { Write-Host ("      已搬    " + $m.Name + "  ->  " + $m.Target) -ForegroundColor DarkGray; continue }
            Write-Host ("   " + (GB $m.Size) + "  " + $m.Name)
            Say-Info $m.Src
            $sum += $m.Size
            $todo++
        }
        Write-Host ''
        Write-Host ('   本次还能腾出：' + (GB $sum) + '（' + $todo + ' 项）') -ForegroundColor Green
        if ($Real -and $todo -gt 0) {
            if ($Yes -or (Ask-Confirm '确认搬家？输入 Y 继续', '^(?!\s*[Yy]\s*$)')) {
                Invoke-MovePlan $plan $root
            }
        }
        exit 0
    }
    if ($Undo) { Invoke-UndoMove; exit 0 }
}

Start-Menu
